/* src/pages/PropertyDetail.jsx */
import BookingCard from "../components/BookingCard";

export default function PropertyDetail() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-6 grid grid-cols-1 lg:grid-cols-3 gap-8">

      {/* LEFT CONTENT */}
      <div className="lg:col-span-2 space-y-10">

        {/* TITLE */}
        <div>
          <h1 className="text-2xl font-semibold">
            Heritage Villa - 3BHK Villa with Private Pool
          </h1>

          <div className="flex items-center gap-2 text-sm mt-1">
            <span className="text-yellow-500">★★★★★</span>
            <span className="text-gray-600">4.8 (127 reviews)</span>
          </div>
        </div>

        {/* IMAGE GRID */}
        <div className="grid grid-cols-3 gap-3 rounded-xl overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1586105251261-72a756497a11"
            className="col-span-2 row-span-2 object-cover h-full w-full"
          />
          <img
            src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2"
            className="object-cover h-full w-full"
          />
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1505691938895-1758d7feb511"
              className="object-cover h-full w-full"
            />
            <button className="absolute bottom-3 right-3 bg-white px-4 py-1 rounded-lg shadow text-sm">
              More photos
            </button>
          </div>
        </div>

        {/* BASIC INFO */}
        <div className="flex flex-wrap gap-6 text-sm text-gray-700 border-b pb-4">
          <span>6–20 Guests</span>
          <span>3 Bedrooms</span>
          <span>3 Bathrooms</span>
          <span>Living Room</span>
          <span>Kitchen</span>
        </div>

        {/* DESCRIPTION */}
        <div>
          <p className="text-gray-700 leading-relaxed">
            Experience luxury and tranquility at Heritage Villa, a stunning
            3BHK property nestled in the heart of North Goa. This exquisite
            villa features a private pool, modern amenities, and authentic
            Goan architecture — perfect for family vacations and group stays.
          </p>
        </div>

        {/* MEALS */}
        <section>
          <h2 className="text-xl font-semibold mb-2">Meals</h2>
          <p className="text-gray-700">
            All meals included · Pure Veg · Authentic Goan cuisine prepared
            with fresh local ingredients.
          </p>
          <button className="mt-2 underline text-sm">View sample menu</button>
        </section>

        {/* AMENITIES */}
        <section>
          <h2 className="text-xl font-semibold mb-3">Amenities</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
            <span>✔ Air Conditioning</span>
            <span>✔ Private Pool</span>
            <span>✔ Free WiFi</span>
            <span>✔ Smart TV</span>
            <span>✔ EV Charger</span>
            <span>✔ Washing Machine</span>
          </div>
        </section>

        {/* LOCATION */}
        <section>
          <h2 className="text-xl font-semibold mb-2">Location</h2>
          <div className="bg-gray-100 h-56 rounded-xl flex items-center justify-center text-gray-500">
            Map will be displayed here
          </div>
          <p className="mt-2 text-sm">
            B12, Villa no 31, Wada Watermark Project, Kundal, Palghar, Maharashtra
          </p>
        </section>

        {/* REVIEWS */}
        <section>
          <h2 className="text-xl font-semibold mb-3">Reviews</h2>

          <div className="border rounded-xl p-4 mb-3">
            <p className="font-medium">Rajesh Kumar</p>
            <p className="text-sm text-gray-600">★★★★★ · March 2024</p>
            <p className="mt-2 text-sm">
              Absolutely stunning property! The villa exceeded our expectations.
            </p>
          </div>

          <button className="border px-4 py-2 rounded-lg text-sm">
            Show all reviews
          </button>
        </section>

        {/* POLICIES */}
        <section>
          <h2 className="text-xl font-semibold mb-2">Policies</h2>
          <ul className="text-sm text-gray-700 space-y-1">
            <li>Check-in: 3:00 PM</li>
            <li>Check-out: 11:00 AM</li>
            <li>Quiet hours: 10:00 PM – 8:00 AM</li>
            <li>No smoking inside rooms</li>
            <li>Outside food not permitted</li>
          </ul>
        </section>

        {/* ABOUT HOST */}
        <section className="border-t pt-6">
          <h2 className="text-xl font-semibold mb-2">About Host</h2>
          <p className="text-sm">Satvik Stays · Host: Navin</p>
        </section>

      </div>

      {/* RIGHT SIDEBAR */}
      <div>
        <BookingCard price="₹8,500" />
      </div>

    </div>
  );
}
