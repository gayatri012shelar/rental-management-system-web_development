/* src/components/SearchBar.jsx */
import { FaSearch, FaSlidersH } from "react-icons/fa";

export default function SearchBar() {
  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-full shadow-md px-6 py-4 flex items-center gap-4">
        
        {/* Location */}
        <div className="flex-1">
          <p className="text-xs font-semibold text-gray-700">Location</p>
          <p className="text-sm text-gray-400">Search destinations</p>
        </div>

        <div className="h-8 w-px bg-gray-200" />

        {/* Check in */}
        <div className="flex-1">
          <p className="text-xs font-semibold text-gray-700">Check in</p>
          <p className="text-sm text-gray-400">Add dates</p>
        </div>

        <div className="h-8 w-px bg-gray-200" />

        {/* Check out */}
        <div className="flex-1">
          <p className="text-xs font-semibold text-gray-700">Check out</p>
          <p className="text-sm text-gray-400">Add dates</p>
        </div>

        <div className="h-8 w-px bg-gray-200" />

        {/* Guests */}
        <div className="flex-1">
          <p className="text-xs font-semibold text-gray-700">Guests</p>
          <p className="text-sm text-gray-400">Select</p>
        </div>

        {/* Search button */}
        <button className="ml-2 h-12 w-12 rounded-full bg-black text-white flex items-center justify-center">
          <FaSearch />
        </button>

        {/* Filters button */}
        <button className="ml-2 px-6 py-3 rounded-full border flex items-center gap-2 text-sm font-medium">
          <FaSlidersH />
          <span>Filters</span>
        </button>
      </div>
    </div>
  );
}
