/* src/components/BookingCard.jsx */
export default function BookingCard({ price }) {
  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 sticky top-24">
      <p className="text-sm text-gray-500 mb-1">Total (3 nights)</p>

      <h2 className="text-2xl font-bold mb-4">{price}</h2>

      <button className="w-full bg-black text-white py-3 rounded-xl mb-3">
        Reserve Now
      </button>

      <div className="flex gap-3">
        <button className="flex-1 bg-blue-500 text-white py-2 rounded-xl">
          Call
        </button>
        <button className="flex-1 bg-green-500 text-white py-2 rounded-xl">
          WhatsApp
        </button>
      </div>
    </div>
  );
}
